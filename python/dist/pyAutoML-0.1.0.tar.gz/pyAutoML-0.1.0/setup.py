from setuptools import setup, find_packages

setup(
    name = "pyAutoML",
    version= "0.1.0",
    author="Databricks",
    packages=find_packages()
    )