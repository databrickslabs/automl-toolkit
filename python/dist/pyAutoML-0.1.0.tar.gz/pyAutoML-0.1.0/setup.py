from setuptools import setup

setup(
    name = "pyAutoML",
    version= "0.1.0",
    author="Databricks"
)